﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotel_Management_System
{
    public partial class EmployeeForm : Form
    {
        public EmployeeForm()
        {
            InitializeComponent();
        }

        private void EmployeeForm_Load(object sender, EventArgs e)
        {
            this.LoadData();
        }
        private void LoadData()
        {
            var query = "select * from Employee";
            DataTable result = DataConnect.GetData(query);

            if (result == null)
            {
                MessageBox.Show("Something Went Wrong");
                return;
            }
            dgvEmployee.AutoGenerateColumns = false;
            dgvEmployee.DataSource = result;
            dgvEmployee.Refresh();
            dgvEmployee.ClearSelection();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            this.LoadData();
            this.NewData();
        }

        private void dgvEmployee_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //   MessageBox.Show(e.RowIndex + "");
            if (e.RowIndex >= 0)
            {
                string id = dgvEmployee.Rows[e.RowIndex].Cells[0].Value.ToString();
                // MessageBox.Show(id);
                this.LoadSingleData(id);
            }

        }
        private void LoadSingleData(string id)
        {
            var query = "select * from Employee where id = " + id + "";
            var result = DataConnect.GetData(query);

            if (result == null)
            {
                MessageBox.Show("Something Went Wrong");
                return;
            }

            txtID.Text = result.Rows[0]["Id"].ToString();
           //txtName.Text = result.Rows[0]["Name"].ToString();   
            txtJobDescription.Text = result.Rows[0]["Job Description"].ToString();
            rtxtAddress.Text = result.Rows[0]["Address"].ToString();



        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            this.NewData();
        }
        private void NewData()
        {
            txtID.Text = "";
            txtName.Text = "";
            txtJobDescription.Text = "";
            rtxtAddress.Text = "";
            dgvEmployee.ClearSelection();

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            this.DeleteData();
        }
        private void DeleteData()
        {

            string id = txtID.Text;

            if (id == "")
            {
                MessageBox.Show("Please select a row first");
                return;

            }
            var userResult = MessageBox.Show("Are You Sure?", "Confirmation", MessageBoxButtons.YesNo);
            if (userResult == DialogResult.No)
            {
                return;
            }
            var query = "delete from Employee where id = " + id + "";
            var result = DataConnect.ExecuteQuery(query);

            if (result == false)
            {
                MessageBox.Show("Something Went Wrong");
                return;
            }
            MessageBox.Show("Deleted");
            this.LoadData();
            this.NewData();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            this.SaveData();
        }
        private void SaveData()
        {
            string id = txtID.Text;
            string name = txtName.Text;
            string job_description = txtJobDescription.Text;
            string address = rtxtAddress.Text;

            if (txtID.Text == "")
            {
                // MessageBox.Show("Insert");

                var query = "insert into Employee ([Name],[Job Description],[Address]) output inserted.Id values ('" + name + "', '" + job_description + "','" + address + "')";
                var result = DataConnect.GetData(query);

                if (result == null)
                {
                    MessageBox.Show("Something Went Wrong");
                    return;
                }
                MessageBox.Show("Information Added");
                txtID.Text = result.Rows[0]["Id"].ToString();


            }
            else
            {
                // MessageBox.Show("Update");

                var query = "update Employee set [Name] = '" + name + "', [Address] = '" + address + "' where id = " + id + "";
                var result = DataConnect.ExecuteQuery(query);

                if (result == false)
                {
                    MessageBox.Show("Something Went Wrong");
                    return;
                }
                MessageBox.Show("Information Updated");


            }
            this.LoadData();

            for (int i = 0; i < dgvEmployee.Rows.Count; i++)
            {
                string selectedId = dgvEmployee.Rows[i].Cells[0].Value.ToString();
                if (selectedId == txtID.Text)
                {
                    dgvEmployee.Rows[i].Selected = true;
                    break;
                }


            }

        }
    }

}